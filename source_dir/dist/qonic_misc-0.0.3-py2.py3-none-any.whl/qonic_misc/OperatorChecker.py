# tool for evaluating operators
